import PyQt5.QtWidgets as PQ
import PyQt5.QtCore as t
import xml.etree.cElementTree as ET
class dodajo:
    def __init__(self):
        #tworzymy okno i dodajemy do niego elementy. okno to ma za zadanie wybrac ucznia przedmiot i wstawic mu jakas ocene i zapisac to do pliku dziennik.xml
        self.okno=PQ.QWidget()
        self.okno.setFixedSize(400,380)
        self.okno.setWindowTitle('wstaw ocene')
        self.uklad=PQ.QVBoxLayout()
        self.okno.setLayout(self.uklad)
        self.n1=PQ.QLabel()
        self.n1.setText("imie i nazwisko:")
        self.n1.setStyleSheet("QLabel {font: 10pt Trebuchet MS;}")
        self.n1.setFixedSize(30,10)
        tree=ET.parse('dziennik.xml')
        #dropbox z imionami i nazwiskami
        self.cb2=PQ.QComboBox()
        self.cb2.addItem("--")
        root=tree.getroot()
        for i in root:
            for j in i:
                    im= j.get("imie")+' '+j.get("nazwisko")
                    self.cb2.addItem(im)
        #dropbox ocenami
        self.cb=PQ.QComboBox()
        self.n3=PQ.QLabel("ocena:")
        self.n3.setFixedSize(60,10)
        self.cb.addItem("1")
        self.cb.addItem("2")
        self.cb.addItem("3")
        self.cb.addItem("4")
        self.cb.addItem("5")
        self.cb.addItem("6")
        #dropbox z przedmiotami
        self.cb1=PQ.QComboBox()
        self.n4=PQ.QLabel("przedmiot:")
        self.n4.setFixedSize(60,15)
        self.cb1.addItem("polski")
        self.cb1.addItem("biologia")
        self.cb1.addItem("matematyka")
        self.cb1.addItem("angielski")
        self.cb1.addItem("historia")
        self.button=PQ.QPushButton("dodaj")
        self.button.clicked.connect(self.dodaj)
        self.uklad.addWidget(self.n1)
        self.uklad.addWidget(self.cb2)
        self.uklad.addWidget(self.n3)
        self.uklad.addWidget(self.cb)
        self.uklad.addWidget(self.n4)
        self.uklad.addWidget(self.cb1)
        self.uklad.addWidget(self.button)
        self.okno.setLayout(self.uklad)
        self.okno.show()
        #self.app.exec_()
       
    def dodaj(self):
        #po kliknieciu przycisku wywolujemy funckje ktora doda ocene ucznia do pliku
            xmldodajo(self.cb2.currentText(),self.cb1.currentText(),self.cb.currentText())
            print("dodano pomyslnie")
def xmldodajo(imnaz,przed,ocena):
   #dodajemy do pliku dziennik.xml ocene dla wybranego ucznia i przedmiotu
    tree=ET.parse('dziennik.xml')
    root=tree.getroot()
    node=root.find("klasa")
    if(node!=None):
        tmp=imnaz
        for i in root:
            for j in i.findall('uczen'):
                im= j.get("imie")+' '+j.get("nazwisko")
                if(im==tmp):
                    for k in j:
                
                        pr=ET.Element("przedmiot",nazwa=przed)
                        
                        if k.attrib==pr.attrib:
                            oc=ET.SubElement(k,"ocena").text=ocena
                            
        tree.write("dziennik.xml")
    else:
        print("nie ma ani jednego ucznia !")
if __name__ == "__main__":
    import sys
    app = PQ.QApplication(sys.argv)
    ui = dodajo()
    ui.okno.show()
    sys.exit(app.exec_())