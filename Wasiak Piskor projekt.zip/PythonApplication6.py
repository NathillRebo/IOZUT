import PyQt5.QtWidgets as PQ
import PyQt5.QtCore as t
from wyswietl import okno
from dodajo import dodajo
from dodaju import dodaju
import xml.etree.cElementTree as ET
import os
from os import path
class menu():
    def __init__(self):
        #tworzymy okno ktore bedzie miec przyciski przekierowujace na inne strony
        self.app=PQ.QApplication([])
        self.okno=PQ.QWidget()
        self.okno.setFixedSize(150,380)
        self.okno.setWindowTitle('Menu')
        self.uklad=PQ.QVBoxLayout()
        
        self.przycisk=PQ.QPushButton("Zobacz oceny")
        self.przycisk.setFixedSize(120,60)
        self.przycisk1=PQ.QPushButton("Dodaj ucznia")
        self.przycisk2=PQ.QPushButton("Wstaw ocene")
        self.przycisk1.setFixedSize(120,60)
        self.przycisk2.setFixedSize(120,60)
        self.przycisk3=PQ.QPushButton("Zamknij")
        self.przycisk3.setFixedSize(120,60)
        self.przycisk.clicked.connect(self.openWindow)
        self.przycisk1.clicked.connect(self.openWindow1)
        self.przycisk2.clicked.connect(self.openWindow2)
       
        self.przycisk3.clicked.connect(self.close)
        self.uklad.addWidget(self.przycisk)
        self.uklad.addWidget(self.przycisk1)
        self.uklad.addWidget(self.przycisk2)
        self.uklad.addWidget(self.przycisk3)
        self.okno.setLayout(self.uklad)
        self.finish = PQ.QAction(self.app)
        self.finish.triggered.connect(self.close)
        #self.okno.show()
        #self.app.exec_()
    def openWindow(self):
        #przekierowanie do wyswietl.py
        self.okno.hide()
        self.ui = okno()
    def openWindow1(self):
         #przekierowanie do dodaju.py
        self.okno.hide()
        self.ui = dodaju()
    def openWindow2(self):
         #przekierowanie do dodajo.py
        self.okno.hide()
        self.ui = dodajo()
    def close(self):
            self.okno.hide()
            self.app.quit()
def create():
    root = ET.Element("dziennik")
    tree = ET.ElementTree(root)
    tree.write("dziennik.xml")



if __name__ == "__main__":
    import sys
    app = PQ.QApplication(sys.argv)
    ui = menu()
    ui.okno.show()
    if path.exists("dziennik.xml"):
        print("baza załadowana")
    else:
        print("baza stworzona")
        create() 
    sys.exit(app.exec_())
    
