import PyQt5.QtWidgets as PQ
import PyQt5.QtCore as t
import xml.etree.cElementTree as ET
class okno:
    def __init__(self):
        #tworzymy okno w ktorym beda wyswietlane informacje o uczniu
       
        self.okno=PQ.QWidget()
        self.okno.setFixedSize(400,380)
        self.okno.setWindowTitle('Zobacz oceny')
        self.uklad=PQ.QVBoxLayout()
        tree=ET.parse('dziennik.xml')
        self.tekst=PQ.QLabel()
        self.tekst.setStyleSheet("QLabel {font: 10pt Trebuchet MS}")
        self.uklad.addWidget(self.tekst)
        #tworzymy dropbox z aktualna lista uczniow
        self.cb=PQ.QComboBox()
        self.cb.addItem("--")
        root=tree.getroot()
        for i in root:
            for j in i:
                    im= j.get("imie")+' '+j.get("nazwisko")
            
                    self.cb.addItem(im)
        self.cb.currentIndexChanged.connect(self.selectionchange)
        self.uklad.addWidget(self.cb)
        self.okno.setLayout(self.uklad)
        self.okno.show()
       
    def selectionchange(self,i):
        #w zaleznosci jakiego ucznia wybierzemy wywola funckje ktora wyswietli dane o nim
                
                self.xmlwysw(self.cb.currentText())
    def xmlwysw(self,x):
        #do stringa wprowadzamy wszystkie dane o wybranym uczniu i wyswietlamy je
        s=""
        tree=ET.parse('dziennik.xml')
        root=tree.getroot()
        for i in root:
                for j in i:
                    im= j.get("imie")+' '+j.get("nazwisko")
                    if x==im:
                    
                        s=s+i.get("klasa")+' \n'
                        s=s+im+' \n'
                        for k in j:
                      
                            s=s+k.get("nazwa")+': '
                            sr=0
                            el=0
                            for l in k:
                           
                                s=s+l.text+' '
                                el+=1
                                sr+=int(l.text)
                            if(el):
                                sr=sr/el
                           
                            s=s+'\n'
                            s=s+'srednia: '+str(sr)+'\n'
        self.tekst.setText(s)
    

if __name__ == "__main__":
    import sys
    app = PQ.QApplication(sys.argv)
    ui = okno()
    ui.okno.show()
    sys.exit(app.exec_())