import PyQt5.QtWidgets as PQ
import PyQt5.QtCore as t
import xml.etree.cElementTree as ET
import unittest
class dodaju( unittest . TestCase):
    #tworzymy okno i dodajemy do niego elementy. okno to ma za zadanie dodawac uczniow do bazy.
    def __init__(self):
        self.okno=PQ.QWidget()
        self.okno.setFixedSize(400,380)
        self.okno.setWindowTitle('dodaj ucznia')
        self.uklad=PQ.QVBoxLayout()
        self.n1=PQ.QLabel()
        #tu wpisujemy imie
        self.n1.setText("imie:")
        self.n1.setStyleSheet("QLabel {font: 10pt Trebuchet MS;}")
        self.n1.setFixedSize(30,10)
        self.e1 = PQ.QLineEdit()
        #tu wpisujemy nazwisko
        self.n2=PQ.QLabel("nazwisko:")
        self.n2.setStyleSheet("QLabel {font: 10pt Trebuchet MS;}")
        self.n2.setFixedSize(60,10)
        self.e2 = PQ.QLineEdit()
        self.cb=PQ.QComboBox()
        #droplista z numerami klas
        self.n3=PQ.QLabel("klasa:")
        self.n3.setFixedSize(60,10)
        self.cb.addItem("1")
        self.cb.addItem("2")
        self.cb.addItem("3")
        self.cb.addItem("4")
        self.cb.addItem("5")
        self.cb.addItem("6")
        #droplista z literami oznaczajaca grupe
        self.cb1=PQ.QComboBox()
        self.cb1.addItem("a")
        self.cb1.addItem("b")
        self.cb1.addItem("c")
        self.cb1.addItem("d")
        self.cb1.addItem("e")
        self.button=PQ.QPushButton("dodaj")
        self.button.clicked.connect(self.dodaj)
        self.uklad.addWidget(self.n1)
        self.uklad.addWidget(self.e1)
        self.uklad.addWidget(self.n2)
        self.uklad.addWidget(self.e2)
        self.uklad.addWidget(self.n3)
        self.uklad.addWidget(self.cb)
        self.uklad.addWidget(self.cb1)
        self.uklad.addWidget(self.button)
        self.okno.setLayout(self.uklad)
        self.okno.show()
       
    def dodaj(self):
        #po kliknieciu przycisku wywolujemy funckje do dodania ucznia do pliku
        self.testempty()
        xmldodaju(self.e1.text(),self.e2.text(),self.cb.currentText(),self.cb1.currentText())
        print("dodano pomyslnie")
    def testempty(self):
        self.assertNotEqual(self.e1.text(),"")
        self.assertNotEqual(self.e2.text(),"")
        self.assertNotIn(" ",self.e1.text())
        self.assertNotIn(" ",self.e2.text())
        self.assertNotIn("0",self.e1.text())
        self.assertNotIn("0",self.e2.text())
        self.assertNotIn("1",self.e1.text())
        self.assertNotIn("1",self.e2.text())
        self.assertNotIn("2",self.e1.text())
        self.assertNotIn("2",self.e2.text())
        self.assertNotIn("3",self.e1.text())
        self.assertNotIn("3",self.e2.text())
        self.assertNotIn("4",self.e1.text())
        self.assertNotIn("4",self.e2.text())
        self.assertNotIn("5",self.e1.text())
        self.assertNotIn("5",self.e2.text())
        self.assertNotIn("6",self.e1.text())
        self.assertNotIn("6",self.e2.text())
        self.assertNotIn("7",self.e1.text())
        self.assertNotIn("7",self.e2.text())
        self.assertNotIn("8",self.e1.text())
        self.assertNotIn("8",self.e2.text())
        self.assertNotIn("9",self.e1.text())
        self.assertNotIn("9",self.e2.text())
       
       
       
def xmldodaju(imie,nazwisko,klasa,grupa):
   #dodajemy do pliku dziennik.xml ucznia i jego klase

    tree=ET.parse('dziennik.xml')
    root=tree.getroot()
    kl=str(klasa)+str(grupa)
    doc = ET.Element( "klasa", klasa=kl)
    b=0
    for i in root:
            if(i.attrib==doc.attrib):
                b=1
                k=i
    
    
    if(b!=1):
        ucz1=ET.SubElement(doc, "uczen", imie=imie,nazwisko=nazwisko) 
        przed=ET.SubElement(ucz1,"przedmiot",nazwa="polski")
        przed=ET.SubElement(ucz1,"przedmiot",nazwa="matematyka")
        przed=ET.SubElement(ucz1,"przedmiot",nazwa="historia")
        przed=ET.SubElement(ucz1,"przedmiot",nazwa="biologia")
        przed=ET.SubElement(ucz1,"przedmiot",nazwa="angielski")
        root.append(doc)
    else:
        ucz1=ET.Element( "uczen", imie=imie,nazwisko=nazwisko) 
        przed=ET.SubElement(ucz1,"przedmiot",nazwa="polski")
        przed=ET.SubElement(ucz1,"przedmiot",nazwa="matematyka")
        przed=ET.SubElement(ucz1,"przedmiot",nazwa="historia")
        przed=ET.SubElement(ucz1,"przedmiot",nazwa="biologia")
        przed=ET.SubElement(ucz1,"przedmiot",nazwa="angielski")
        k.append(ucz1)

    
    tree.write("dziennik.xml")
if __name__ == "__main__":
    import sys
    app = PQ.QApplication(sys.argv)
    ui = dodaju()
    
    ui.okno.show()
    sys.exit(app.exec_())